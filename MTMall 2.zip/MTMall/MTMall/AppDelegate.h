//
//  AppDelegate.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/19.
//

#import <UIKit/UIKit.h>
#import <WXApi.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,WXApiDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

