//
//  SubmitOrderViewController.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>
#import "ShopDetailsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SubmitOrderViewController : UIViewController

@property (nonatomic, strong) NSMutableArray<ShopDetailsModel *> *dataArrays;

@property (nonatomic,copy) void(^tuochPayCompletionBlock)(void);

@end

NS_ASSUME_NONNULL_END
