//
//  ShopDetailsModel.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/19.
//

#import "ShopDetailsModel.h"

@implementation ShopDetailsModel

- (instancetype)initWithDictionary:(NSDictionary *)dictionary {
    self = [super init];
    if (self) {

    }
    return self;
}

@end
