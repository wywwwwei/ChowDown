//
//  ShoppingCartViewCell.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/19.
//

#import <UIKit/UIKit.h>
#import "ShopDetailsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ShoppingCartViewCell : UITableViewCell

@property (nonatomic, strong) ShopDetailsModel *model;

@property (nonatomic,copy) void(^tuochAddOrDecreaseBlock)(void);

@end

NS_ASSUME_NONNULL_END
