//
//  SubmitOrderFooterView.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubmitOrderFooterView : UIView

@property(nonatomic, strong) UIButton *selectButton;

@end

NS_ASSUME_NONNULL_END
