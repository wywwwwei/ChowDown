//
//  SubmitOrderTableViewCell.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>
#import "ShopDetailsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SubmitOrderTableViewCell : UITableViewCell

@property (nonatomic, strong) ShopDetailsModel *model;

@end

NS_ASSUME_NONNULL_END
