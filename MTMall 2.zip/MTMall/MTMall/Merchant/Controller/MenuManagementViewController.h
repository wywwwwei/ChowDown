//
//  MenuManagementViewController.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MenuManagementViewController : UIViewController

@property (nonatomic, strong) UITableView *tableView;

@end

NS_ASSUME_NONNULL_END
