//
//  MenuManagementViewController.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import "MenuManagementViewController.h"
#import <Masonry/Masonry.h>
#import "ShopDetailsModel.h"
#import "MenuManagementTableViewCell.h"
#import "MenuManagementModel.h"
#import <SVProgressHUD/SVProgressHUD.h>

@interface MenuManagementViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray<MenuManagementModel *> *dataArrays;

@property (nonatomic, strong) NSMutableArray<MenuManagementModel *> *selectDataArrays;

@property (nonatomic, strong) UITextField *textFiled;

@end

@implementation MenuManagementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self createUI];
    [self loadData];
}

- (void)createUI {
    [self.view addSubview:self.tableView];

    [self.view addSubview:self.textFiled];

    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.mas_equalTo(60);
        make.bottom.mas_equalTo(0);
    }];

    [self.textFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-15);
        make.height.mas_equalTo(40);
    }];
}

- (void)loadData {
    NSMutableArray<MenuManagementModel *> *arrays = [NSMutableArray array];

    NSArray *names = @[@"Ebi Series Combo for 3",@"Ebi Combo for 2",@"Ebi Burger with Fish Combo for 1",@"Ebi Burger with Pineapple Combo for 1",@"Ebi Burger Combo for 1",@"Crispy Thighs Sharing Bucket Combo for 3",@"Burger Lovers Combo for 3",@"Crispy Thighs Sharing Bucket Combo for 2",@"Burger Lovers Combo for 2"];
    NSArray *prices = @[@"189.00",@"126.00",@"69.00",@"66.00",@"63.00",@"183.00",@"159.00",@"128.00",@"115.00"];

    for (int i = 0; i< names.count; i++) {
        MenuManagementModel *model = [[MenuManagementModel alloc] init];
        model.menuId = [NSString stringWithFormat:@"%d", i];
        model.name = names[i];
        model.coverUrl = [NSString stringWithFormat:@"%d.jpeg",i + 1];
        model.type = i%2;
        model.price = prices[i];
        [arrays addObject:model];
    }
    self.dataArrays = arrays;
    for (MenuManagementModel *model in self.dataArrays) {
        [self.selectDataArrays addObject:model];
    }
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.selectDataArrays.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MenuManagementTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MenuManagementTableViewCell" forIndexPath:indexPath];
    [cell setModel:self.selectDataArrays[indexPath.row]];
    __weak typeof(self) weakSelf = self;
    cell.tuochDeleteEventBlock = ^{
        MenuManagementModel *tempModel = weakSelf.selectDataArrays[indexPath.row];
        for (MenuManagementModel *model in self.dataArrays) {
            if ([model.menuId isEqualToString:tempModel.menuId]) {
                [self.dataArrays removeObject:model];
                break;
            }
        }
        [weakSelf.selectDataArrays removeObjectAtIndex:indexPath.row];
        [weakSelf.tableView reloadData];
        [SVProgressHUD setMaximumDismissTimeInterval:0.5];
        [SVProgressHUD showSuccessWithStatus:@"Successfully deleted"];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 170.0;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)textViewValueChanged {
    NSString *strUrl = [self.textFiled.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (strUrl.length == 0) {
        for (MenuManagementModel *model in self.dataArrays) {
            [self.selectDataArrays addObject:model];
        }
    } else {
        [self.selectDataArrays removeAllObjects];
        for (MenuManagementModel *model in self.dataArrays) {
            if ([model.name containsString:strUrl]) {
                [self.selectDataArrays addObject:model];
            }
        }
    }
    [self.tableView reloadData];
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [_tableView registerClass:[MenuManagementTableViewCell class] forCellReuseIdentifier:@"MenuManagementTableViewCell"];
    }
    return _tableView;
}

- (NSMutableArray<MenuManagementModel *> *)selectDataArrays {
    if (!_selectDataArrays) {
        _selectDataArrays = [[NSMutableArray alloc] init];
    }

    return _selectDataArrays;
}

- (UITextField *)textFiled {
    if (!_textFiled) {
        _textFiled = [[UITextField alloc] init];
        _textFiled.leftViewMode = UITextFieldViewModeAlways;
        _textFiled.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 15, 40)];
        _textFiled.layer.cornerRadius = 6;
        _textFiled.layer.masksToBounds = true;
        _textFiled.layer.borderColor = [[UIColor darkGrayColor] CGColor];
        _textFiled.layer.borderWidth = 1;
        _textFiled.font = [UIFont systemFontOfSize:16];
        _textFiled.textColor = [UIColor blackColor];
        _textFiled.placeholder = @"Please enter the name of the search";
        [_textFiled addTarget:self action:@selector(textViewValueChanged) forControlEvents:UIControlEventAllEditingEvents];
    }

    return _textFiled;
}

@end

