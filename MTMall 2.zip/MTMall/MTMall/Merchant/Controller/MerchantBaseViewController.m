//
//  MerchantBaseViewController.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import "MerchantBaseViewController.h"
#import <YNPageViewController/YNPageViewController.h>
#import "OrderViewController.h"
#import "MenuManagementViewController.h"

@interface MerchantBaseViewController ()
<YNPageViewControllerDataSource,
YNPageViewControllerDelegate,
YNPageScrollMenuViewDelegate>

@property (nonatomic, strong) YNPageViewController *pageViewController;

@property (nonatomic, strong) OrderViewController *orderViewController;

@property (nonatomic, strong) MenuManagementViewController *menuViewController;

@end

@implementation MerchantBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Merchant side";
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self createUI];
    [self loadData];
}

- (void)createUI {
    [self.pageViewController addSelfToParentViewController:self];
}

- (void)loadData {

}

#pragma mark --- YNPageViewControllerDataSource代理方法

- (UIScrollView *)pageViewController:(YNPageViewController *)pageViewController pageForIndex:(NSInteger)index {
    if (index == 0) {
        return self.orderViewController.tableView;
    }
    return self.menuViewController.tableView;
}

- (NSString *)pageViewController:(YNPageViewController *)pageViewController
          customCacheKeyForIndex:(NSInteger )index {
    NSArray *arrays = @[@"Order management",@"Menu management"];
    return arrays[index];
}

#pragma mark --- YNPageScrollMenuViewDelegate代理方法

- (void)pageViewController:(YNPageViewController *)pageViewController
         didScrollMenuItem:(UIButton *)itemButton
                     index:(NSInteger)index {

}

/** 获取分页的视图控制器数组 */
- (NSArray *)getVCArrays {
    NSMutableArray * arrays = [NSMutableArray new];
    self.orderViewController = [[OrderViewController alloc] init];
    self.menuViewController = [[MenuManagementViewController alloc] init];
    [arrays addObject:self.orderViewController];
    [arrays addObject:self.menuViewController];
    return arrays;
}

- (YNPageViewController *)pageViewController {
    if (!_pageViewController) {
        YNPageConfigration *configration = [YNPageConfigration defaultConfig];
        configration.itemFont = [UIFont boldSystemFontOfSize:18];
        configration.selectedItemFont = [UIFont boldSystemFontOfSize:18];
        configration.normalItemColor = [UIColor darkGrayColor];
        configration.selectedItemColor = [UIColor blackColor];
        configration.itemMaxScale = 0;
        configration.lineWidthEqualFontWidth = YES;
        configration.showTabbar = NO;
        configration.showNavigation = YES;
        configration.menuHeight = 0;
        configration.scrollMenu = NO;
        configration.aligmentModeCenter = NO;
        configration.showBottomLine = YES;
        configration.bottomLineHeight = 0;
        configration.menuHeight = 44;
        _pageViewController = [YNPageViewController pageViewControllerWithControllers:self.getVCArrays
                                                                               titles:@[@"Order management",@"Menu management"]
                                                                               config:configration];
        _pageViewController.dataSource = self;
        _pageViewController.delegate = self;
        _pageViewController.bgScrollView.scrollsToTop = NO;
    }
    return _pageViewController;
}

@end
