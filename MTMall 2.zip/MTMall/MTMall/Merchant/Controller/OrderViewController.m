//
//  OrderViewController.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import "OrderViewController.h"
#import <Masonry/Masonry.h>
#import "ShopDetailsModel.h"
#import "OrderTableViewCell.h"
#import "OrderModel.h"
#import "OrderDetailsViewController.h"

@interface OrderViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray<OrderModel *> *dataArrays;

@property (nonatomic, strong) NSMutableArray<OrderModel *> *selectDataArrays;

@property (nonatomic, strong) UITextField *textFiled;

@end

@implementation OrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self createUI];
    [self loadData];
}

- (void)createUI {
    [self.view addSubview:self.textFiled];
    [self.view addSubview:self.tableView];

    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(0);
        make.top.mas_equalTo(60);
        make.bottom.mas_equalTo(0);
    }];

    [self.textFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.top.mas_equalTo(10);
        make.right.mas_equalTo(-15);
        make.height.mas_equalTo(40);
    }];
}

- (void)loadData {
    NSMutableArray<OrderModel *> *arrays = [NSMutableArray array];
    for (int i = 0; i< 20; i++) {
        OrderModel *model = [[OrderModel alloc] init];
        model.orderCode = [NSString stringWithFormat:@"542%d", i + 100];;
        model.orderType = i % 4;
        model.name = @"Jackhorse";
        model.phone = @"001(358)1395590";
        model.address = @"Albertson Oldsmobile Chevrolet";
        model.time = @"2024-06-06";
        model.price = @"100";
        [arrays addObject:model];
    }
    self.dataArrays = arrays;
    for (OrderModel *model in self.dataArrays) {
        [self.selectDataArrays addObject:model];
    }
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.selectDataArrays.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OrderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderTableViewCell" forIndexPath:indexPath];
    [cell setModel:self.selectDataArrays[indexPath.row]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 150.0;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    OrderDetailsViewController *orderDetailsViewController = [[OrderDetailsViewController alloc] init];
    orderDetailsViewController.model = self.dataArrays[indexPath.row];
    [self.navigationController pushViewController:orderDetailsViewController animated:true];
}

- (void)textViewValueChanged {
    NSString *strUrl = [self.textFiled.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (strUrl.length == 0) {
        for (OrderModel *model in self.dataArrays) {
            [self.selectDataArrays addObject:model];
        }
    } else {
        [self.selectDataArrays removeAllObjects];
        for (OrderModel *model in self.dataArrays) {
            if ([model.orderCode containsString:strUrl]) {
                [self.selectDataArrays addObject:model];
            }
        }
    }
    [self.tableView reloadData];
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [_tableView registerClass:[OrderTableViewCell class] forCellReuseIdentifier:@"OrderTableViewCell"];
    }
    return _tableView;
}


- (NSMutableArray<OrderModel *> *)selectDataArrays {
    if (!_selectDataArrays) {
        _selectDataArrays = [[NSMutableArray alloc] init];
    }

    return _selectDataArrays;
}

- (UITextField *)textFiled {
    if (!_textFiled) {
        _textFiled = [[UITextField alloc] init];
        _textFiled.leftViewMode = UITextFieldViewModeAlways;
        _textFiled.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 15, 40)];
        _textFiled.layer.cornerRadius = 6;
        _textFiled.layer.masksToBounds = true;
        _textFiled.layer.borderColor = [[UIColor darkGrayColor] CGColor];
        _textFiled.layer.borderWidth = 1;
        _textFiled.font = [UIFont systemFontOfSize:16];
        _textFiled.textColor = [UIColor blackColor];
        _textFiled.placeholder = @"Please enter the order number to search";
        [_textFiled addTarget:self action:@selector(textViewValueChanged) forControlEvents:UIControlEventAllEditingEvents];
    }

    return _textFiled;
}


@end
