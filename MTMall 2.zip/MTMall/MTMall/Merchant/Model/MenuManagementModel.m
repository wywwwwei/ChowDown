//
//  MenuManagementModel.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import "MenuManagementModel.h"

@implementation MenuManagementModel

- (NSString *)typeString {
    if (self.type == 0) {
        return @"On sale";
    }
    if (self.type == 1) {
        return @"Stop sale";
    }
    return @"";
}

@end
