//
//  MenuManagementTableViewCell.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>
#import "MenuManagementModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MenuManagementTableViewCell : UITableViewCell

@property (nonatomic, strong) MenuManagementModel *model;

@property (nonatomic,copy) void(^tuochDeleteEventBlock)(void);

@end

NS_ASSUME_NONNULL_END
