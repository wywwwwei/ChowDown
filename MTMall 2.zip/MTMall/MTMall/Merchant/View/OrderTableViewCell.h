//
//  OrderTableViewCell.h
//  MTMall
//
//  Created by 丢丢立 on 2024/6/20.
//

#import <UIKit/UIKit.h>
#import "OrderModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OrderTableViewCell : UITableViewCell

@property (nonatomic, strong) OrderModel *model;

@end

NS_ASSUME_NONNULL_END
