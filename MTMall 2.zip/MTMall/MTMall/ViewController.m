//
//  ViewController.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/19.
//

#import "ViewController.h"
#import <WXApi.h>
#import <Masonry/Masonry.h>
#import "ShopDetailsViewController.h"
#import "MerchantBaseViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    UIButton *mallButton = [[UIButton alloc] init];
    [mallButton setTitle:@"client" forState:UIControlStateNormal];
    mallButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [mallButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [mallButton addTarget:self action:@selector(touchMallButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    mallButton.backgroundColor = [UIColor grayColor];
    [self.view addSubview:mallButton];


    UIButton *mallTwoButton = [[UIButton alloc] init];
    [mallTwoButton setTitle:@"Merchant" forState:UIControlStateNormal];
    mallTwoButton.backgroundColor = [UIColor grayColor];
    mallTwoButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [mallTwoButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [mallTwoButton addTarget:self action:@selector(touchMallTwoButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:mallTwoButton];

    [mallButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.centerY.mas_equalTo(-100);
        make.size.mas_equalTo(CGSizeMake(100, 100));
    }];

    [mallTwoButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.top.equalTo(mallButton.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(100, 100));
    }];

}

/// 外卖客户端
- (void)touchMallButtonEvent {
    ShopDetailsViewController *shopDetailsViewController = [[ShopDetailsViewController alloc] init];
    [self.navigationController pushViewController:shopDetailsViewController animated:true];
}

/// 商家客户端
- (void)touchMallTwoButtonEvent {
    MerchantBaseViewController *merchantBaseViewController = [[MerchantBaseViewController alloc] init];
    [self.navigationController pushViewController:merchantBaseViewController animated:true];
}

@end

/// 微信跳转支付
//PayReq *req  = [[PayReq alloc] init];
//req.partnerId = @"123131231";
//req.prepayId = @"123131231";
//req.package =  @"123131231";
//req.nonceStr =  @"123131231";
//req.timeStamp =  123131231;
//req.sign =  @"123131231";
//[WXApi sendReq:req completion:^(BOOL success) {
//
//}];
