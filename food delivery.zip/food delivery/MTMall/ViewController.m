//
//  ViewController.m
//  MTMall
//
//  Created by 丢丢立 on 2024/6/19.
//

#import "ViewController.h"
#import <WXApi.h>
#import <Masonry/Masonry.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor greenColor];

    UIButton *wx = [[UIButton alloc] init];
    [wx setTitle:@"跳转微信" forState:UIControlStateNormal];
    wx.backgroundColor = [UIColor orangeColor];
    [wx setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:wx];

    [wx mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(100, 100));
    }];

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //    [WXApi openWXApp];
    PayReq *req  = [[PayReq alloc] init];
    req.partnerId = @"123131231";
    req.prepayId = @"123131231";
    req.package =  @"123131231";
    req.nonceStr =  @"123131231";
    req.timeStamp =  123131231;
    req.sign =  @"123131231";
    [WXApi sendReq:req completion:^(BOOL success) {

    }];
}


@end
